package com.mahi.spring.getapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoSpringGetapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
