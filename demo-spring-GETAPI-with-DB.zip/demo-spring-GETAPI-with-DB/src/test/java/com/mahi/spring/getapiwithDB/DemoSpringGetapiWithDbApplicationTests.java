package com.mahi.spring.getapiwithDB;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoSpringGetapiWithDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
